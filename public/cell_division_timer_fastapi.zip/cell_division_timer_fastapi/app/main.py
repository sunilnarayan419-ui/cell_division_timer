"""Main FastAPI application entrypoint."""

from contextlib import asynccontextmanager
from typing import AsyncGenerator
from fastapi import FastAPI, Request, status
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from app.api.routes import api_router
from app.api.routes.health import router as health_router
from app.core.config import get_settings
from app.core.database import Base, engine
from app.core.logging import logger

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan context manager for startup and shutdown hooks."""
    logger.info(f"Starting {settings.APP_NAME} v{settings.APP_VERSION} [{settings.APP_ENV}]")
    # Initialize database tables
    try:
        Base.metadata.create_all(bind=engine)
        logger.info(f"Database initialized successfully ({engine.dialect.name})")
    except Exception as exc:
        logger.error(f"Failed to initialize database tables: {exc}")

    yield

    logger.info("Shutting down Cell Division Timer API gracefully")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description=(
        "**Cell Division Timer** is a production biotechnology life-sciences backend platform "
        "for tracking, modeling, and analyzing cell-cycle and mitotic division dynamics across "
        "experimental conditions, temperature gradients, and cellular generations."
    ),
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url=f"{settings.API_PREFIX}/openapi.json",
    lifespan=lifespan,
)

# Configure Cross-Origin Resource Sharing (CORS)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Global Exception Handlers
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    """Provide clean, structured error responses for Pydantic validation failures."""
    errors = []
    for err in exc.errors():
        field = " -> ".join(str(loc) for loc in err.get("loc", []))
        errors.append(f"{field}: {err.get('msg')}")
    error_message = "; ".join(errors)
    logger.warning(f"Validation error on {request.method} {request.url.path}: {error_message}")
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "detail": error_message,
            "code": "VALIDATION_ERROR",
            "errors": jsonable_encoder(exc.errors()),
        },
    )


@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Catch-all exception handler to prevent unhandled internal leakages."""
    logger.error(f"Unhandled internal server error on {request.method} {request.url.path}: {exc}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "detail": "An internal server error occurred while processing the request",
            "code": "INTERNAL_SERVER_ERROR",
        },
    )


# Mount routers
app.include_router(health_router)
app.include_router(api_router, prefix=settings.API_PREFIX)


@app.get("/", tags=["General"], summary="Root API Directory")
def root_info() -> dict:
    """API root metadata and documentation links."""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "environment": settings.APP_ENV,
        "documentation": "/docs",
        "redoc": "/redoc",
        "health": "/health",
        "api_v1_prefix": settings.API_PREFIX,
        "message": "Cell Division Timer - Biotechnology Life-Sciences Platform Active",
    }
